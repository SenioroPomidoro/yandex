from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class JobsForm(FlaskForm):
    team_leader = StringField("Team leader", validators=[DataRequired()])
    job = StringField("Title of activity", validators=[DataRequired()])
    work_size = StringField("Duration(in_hours)", validators=[DataRequired()])
    collaborators = StringField("List of collaborators", validators=[DataRequired()])
    is_finished = BooleanField("Is finished")
    category = StringField("Category Id (from 1 to 20)", validators=[DataRequired()])
    submit = SubmitField("Submit")
