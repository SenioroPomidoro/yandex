import json
import os

import datetime
from data import db_session
from data.users import User
from data.jobs import Jobs

from flask import Flask, render_template, url_for, redirect, request
from forms.user import RegisterForm
# ----------------------------------------------------------------------------------------------------------------------

app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
@app.route("/index")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    for item in range(len(jobs)):
        user = db_sess.query(User).filter(User.id == jobs[item].team_leader)[0]
        username = user.surname + " " + user.name
        jobs[item] = [username, jobs[item]]
    return render_template("index.html", jobs=jobs)


@app.route("/register", methods=["POST", "GET"])
def register():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template("register.html", title="Регистрация", form=form,
                                   message="Пароли не совпадают")
        db_sess = db_session.create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template("register.html", title="Регистрация", form=form,
                                   message="Пользователь с таким email уже есть")
        user = User(
                    surname=form.surname.data,
                    name=form.name.data,
                    email=form.email.data,
                    age=form.age.data,
                    position=form.position.data,
                    speciality=form.speciallity.data,
                    address=form.address.data
        )
        user.set_password(form.password.data)
        db_sess.add(user)
        db_sess.commit()
        return render_template("register.html", title="Регистрация", form=form, message="Успешно")
    return render_template("register.html", title="Регистрация", form=form)


def main():
    db_session.global_init("db/blogs.db")
    app.run(host="127.0.0.1", port=8080, debug=True)


if __name__ == "__main__":
    main()
