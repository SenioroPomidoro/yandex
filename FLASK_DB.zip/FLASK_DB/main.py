import json
import os

import datetime

from data import db_session

from data.users import User
from data.jobs import Jobs

from flask import Flask, render_template, url_for, redirect, request

# ----------------------------------------------------------------------------------------------------------------------


app = Flask(__name__)
app.config['SECRET_KEY'] = 'yandexlyceum_secret_key'


@app.route("/")
@app.route("/index")
def index():
    db_sess = db_session.create_session()
    jobs = db_sess.query(Jobs).all()
    for item in range(len(jobs)):
        user = db_sess.query(User).filter(User.id == jobs[item].team_leader)[0]
        username = user.surname + " " + user.name
        jobs[item] = [username, jobs[item]]
    return render_template("index.html", jobs=jobs)


def main():
    db_session.global_init("db/blogs.db")

    app.run(host="127.0.0.1", port=8080, debug=True)


if __name__ == "__main__":
    main()
